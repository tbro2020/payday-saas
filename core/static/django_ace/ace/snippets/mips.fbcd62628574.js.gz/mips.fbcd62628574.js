
;                (function() {
                    window.require(["ace/snippets/mips"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            